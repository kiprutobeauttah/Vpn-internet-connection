# Fast-Browse

A powerful Chrome extension that combines ad blocking and data compression to save bandwidth and speed up your browsing experience.

**Author:** Mr.Beauttah  
**GitHub:** [github.com/kiprutobeauttah](https://github.com/kiprutobeauttah)

## Features

- **Ad Blocking**: Block ads from major advertising networks
- **Tracker Blocking**: Stop analytics and tracking scripts
- **Data Compression**: Compress web traffic to save up to 90% bandwidth
- **Real-time Statistics**: Monitor blocked content and data saved
- **Privacy-Focused**: No data collection or tracking
- **Lightweight**: Minimal resource usage

## Installation

### From Source

1. Download or clone this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" in the top right
4. Click "Load unpacked"
5. Select the `DataSaver-Extension` folder
6. The extension is now installed!

### Generate Icons

1. Open `icons/generate-icons.html` in your browser
2. Right-click each canvas and save as PNG:
   - Save first canvas as `icon16.png`
   - Save second canvas as `icon48.png`
   - Save third canvas as `icon128.png`
3. Place all PNG files in the `icons/` folder

## Usage

1. Click the extension icon in your browser toolbar
2. View real-time statistics:
   - Total data saved
   - Ads blocked
   - Trackers blocked
   - Compression ratio
3. Toggle features on/off:
   - Ad Blocker
   - Data Compression
4. Reset statistics anytime

## How It Works

### Ad Blocking
Uses DNS-based blocking to prevent ads and trackers from loading, saving bandwidth and improving page load times.

### Data Compression
Compresses web content before it reaches your browser, reducing data usage by 50-90% depending on content type.

## Statistics Tracked

- **Total Data Saved**: Estimated bandwidth saved through blocking and compression
- **Ads Blocked**: Number of ad requests blocked
- **Trackers Blocked**: Number of tracking scripts blocked
- **Total Blocked**: Combined blocked requests
- **Compression Ratio**: Percentage of data saved through compression

## Privacy

This extension does NOT:
- Collect any personal data
- Track your browsing history
- Send data to external servers
- Require account registration

All data is stored locally on your device.

## Blocked Networks

### Ad Networks
- Google Ads (doubleclick.net, googlesyndication.com)
- Facebook Ads (facebook.net)
- Amazon Ads (amazon-adsystem.com)
- And 10+ more networks

### Trackers
- Google Analytics
- Facebook Pixel
- Hotjar
- Mixpanel
- And 10+ more trackers

## License

Apache License 2.0

Copyright (c) 2026 Mr.Beauttah

## Contact

- Email: kiprutobeauttah@gmail.com
- GitHub: [github.com/kiprutobeauttah](https://github.com/kiprutobeauttah)

## Version

1.0.0

## Support

For issues, feature requests, or support, please contact:
- Email: kiprutobeauttah@gmail.com
- GitHub Issues: [github.com/kiprutobeauttah](https://github.com/kiprutobeauttah)
