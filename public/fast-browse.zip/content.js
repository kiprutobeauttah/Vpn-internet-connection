const observer = new MutationObserver((mutations) => {
  mutations.forEach((mutation) => {
    mutation.addedNodes.forEach((node) => {
      if (node.nodeType === 1) {
        removeAds(node);
      }
    });
  });
});

observer.observe(document.documentElement, {
  childList: true,
  subtree: true
});

function removeAds(element) {
  const adSelectors = [
    '[class*="ad-"]',
    '[id*="ad-"]',
    '[class*="advertisement"]',
    '[id*="advertisement"]',
    'iframe[src*="doubleclick"]',
    'iframe[src*="googlesyndication"]',
    '[class*="sponsored"]',
    '[data-ad-slot]',
    '.ad',
    '.ads',
    '#ad',
    '#ads'
  ];

  adSelectors.forEach(selector => {
    try {
      const ads = element.querySelectorAll ? element.querySelectorAll(selector) : [];
      ads.forEach(ad => {
        if (ad && ad.parentNode) {
          ad.remove();
        }
      });
    } catch (e) {
      console.error('Error removing ads:', e);
    }
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    removeAds(document.body);
  });
} else {
  removeAds(document.body);
}

const style = document.createElement('style');
style.textContent = `
  [class*="ad-"],
  [id*="ad-"],
  [class*="advertisement"],
  [id*="advertisement"],
  iframe[src*="doubleclick"],
  iframe[src*="googlesyndication"],
  [class*="sponsored"],
  [data-ad-slot] {
    display: none !important;
    visibility: hidden !important;
    opacity: 0 !important;
    height: 0 !important;
    width: 0 !important;
  }
`;
document.head.appendChild(style);
