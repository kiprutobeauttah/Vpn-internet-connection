let stats = {
  adsBlocked: 0,
  trackersBlocked: 0,
  dataSaved: 0,
  originalSize: 0,
  compressedSize: 0,
  requestsBlocked: 0
};

let compressionEnabled = true;
let adBlockEnabled = true;

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ 
    stats: stats,
    compressionEnabled: true,
    adBlockEnabled: true
  });
  console.log('DataSaver Pro installed');
});

chrome.storage.local.get(['stats', 'compressionEnabled', 'adBlockEnabled'], (result) => {
  if (result.stats) stats = result.stats;
  if (result.compressionEnabled !== undefined) compressionEnabled = result.compressionEnabled;
  if (result.adBlockEnabled !== undefined) adBlockEnabled = result.adBlockEnabled;
});

chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((details) => {
  if (details.rule.rulesetId === 'ads_blocklist') {
    stats.adsBlocked++;
    stats.requestsBlocked++;
  } else if (details.rule.rulesetId === 'trackers_blocklist') {
    stats.trackersBlocked++;
    stats.requestsBlocked++;
  }
  
  stats.dataSaved += estimateBlockedSize(details.request.url);
  saveStats();
});

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (!compressionEnabled) return;
    
    if (shouldCompress(details.url)) {
      return {
        redirectUrl: getCompressedUrl(details.url)
      };
    }
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);

chrome.webRequest.onCompleted.addListener(
  (details) => {
    if (details.responseHeaders) {
      const contentLength = getContentLength(details.responseHeaders);
      if (contentLength > 0) {
        stats.originalSize += contentLength;
        
        if (isCompressed(details.responseHeaders)) {
          stats.compressedSize += contentLength;
          stats.dataSaved += Math.floor(contentLength * 0.3);
        }
        
        saveStats();
      }
    }
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);

function shouldCompress(url) {
  const compressibleTypes = ['.html', '.css', '.js', '.json', '.xml', '.svg'];
  return compressibleTypes.some(type => url.includes(type));
}

function getCompressedUrl(url) {
  return url;
}

function isCompressed(headers) {
  const encoding = headers.find(h => h.name.toLowerCase() === 'content-encoding');
  return encoding && (encoding.value.includes('gzip') || encoding.value.includes('br'));
}

function getContentLength(headers) {
  const length = headers.find(h => h.name.toLowerCase() === 'content-length');
  return length ? parseInt(length.value) : 0;
}

function estimateBlockedSize(url) {
  if (url.includes('doubleclick') || url.includes('googlesyndication')) {
    return 50000;
  }
  if (url.includes('analytics') || url.includes('tracking')) {
    return 10000;
  }
  return 5000;
}

function saveStats() {
  chrome.storage.local.set({ stats: stats });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getStats') {
    sendResponse({ stats: stats });
  } else if (request.action === 'resetStats') {
    stats = {
      adsBlocked: 0,
      trackersBlocked: 0,
      dataSaved: 0,
      originalSize: 0,
      compressedSize: 0,
      requestsBlocked: 0
    };
    saveStats();
    sendResponse({ success: true });
  } else if (request.action === 'toggleCompression') {
    compressionEnabled = request.enabled;
    chrome.storage.local.set({ compressionEnabled: compressionEnabled });
    sendResponse({ success: true });
  } else if (request.action === 'toggleAdBlock') {
    adBlockEnabled = request.enabled;
    chrome.storage.local.set({ adBlockEnabled: adBlockEnabled });
    
    chrome.declarativeNetRequest.updateEnabledRulesets({
      enableRulesetIds: request.enabled ? ['ads_blocklist', 'trackers_blocklist'] : [],
      disableRulesetIds: request.enabled ? [] : ['ads_blocklist', 'trackers_blocklist']
    });
    
    sendResponse({ success: true });
  }
  return true;
});

chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });

setInterval(() => {
  chrome.action.setBadgeText({ 
    text: stats.requestsBlocked > 999 ? '999+' : stats.requestsBlocked.toString() 
  });
}, 1000);
