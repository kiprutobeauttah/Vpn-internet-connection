function formatBytes(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
}

function updateStats() {
  chrome.runtime.sendMessage({ action: 'getStats' }, (response) => {
    if (response && response.stats) {
      const stats = response.stats;
      
      document.getElementById('adsBlocked').textContent = stats.adsBlocked.toLocaleString();
      document.getElementById('trackersBlocked').textContent = stats.trackersBlocked.toLocaleString();
      document.getElementById('requestsBlocked').textContent = stats.requestsBlocked.toLocaleString();
      document.getElementById('totalSaved').textContent = formatBytes(stats.dataSaved);
      
      const compressionRatio = stats.originalSize > 0 
        ? Math.round(((stats.originalSize - stats.compressedSize) / stats.originalSize) * 100)
        : 0;
      document.getElementById('compressionRatio').textContent = compressionRatio + '%';
    }
  });
}

document.getElementById('adBlockToggle').addEventListener('change', (e) => {
  chrome.runtime.sendMessage({ 
    action: 'toggleAdBlock', 
    enabled: e.target.checked 
  });
});

document.getElementById('compressionToggle').addEventListener('change', (e) => {
  chrome.runtime.sendMessage({ 
    action: 'toggleCompression', 
    enabled: e.target.checked 
  });
});

document.getElementById('resetBtn').addEventListener('click', () => {
  if (confirm('Are you sure you want to reset all statistics?')) {
    chrome.runtime.sendMessage({ action: 'resetStats' }, () => {
      updateStats();
    });
  }
});

chrome.storage.local.get(['adBlockEnabled', 'compressionEnabled'], (result) => {
  if (result.adBlockEnabled !== undefined) {
    document.getElementById('adBlockToggle').checked = result.adBlockEnabled;
  }
  if (result.compressionEnabled !== undefined) {
    document.getElementById('compressionToggle').checked = result.compressionEnabled;
  }
});

updateStats();
setInterval(updateStats, 2000);
