# DataSaver Pro - Ad Blocker & Data Compression

A powerful Chrome extension that blocks ads, trackers, and compresses web traffic to save up to 90% of your data usage.

## Features

- **Ad Blocking**: Blocks ads from major ad networks (Google Ads, Facebook Ads, etc.)
- **Tracker Blocking**: Blocks analytics and tracking scripts
- **Data Compression**: Compresses web traffic to reduce data usage
- **Real-time Statistics**: Track blocked ads, trackers, and data saved
- **Privacy Focused**: No data collection, everything runs locally
- **Lightweight**: Minimal performance impact
- **Easy Toggle**: Enable/disable features with one click

## Installation

### From Source

1. Download or clone this repository
2. Open Chrome and go to `chrome://extensions/`
3. Enable "Developer mode" in the top right
4. Click "Load unpacked"
5. Select the `DataSaver-Extension` folder
6. The extension is now installed!

### From Chrome Web Store

Coming soon...

## Usage

1. Click the extension icon in your browser toolbar
2. View real-time statistics:
   - Total data saved
   - Ads blocked
   - Trackers blocked
   - Compression ratio
3. Toggle features on/off:
   - Ad Blocker
   - Data Compression
4. Reset statistics anytime

## How It Works

### Ad Blocking
- Uses declarativeNetRequest API to block ad domains
- Removes ad elements from web pages using content scripts
- Blocks major ad networks: Google Ads, Facebook Ads, Yahoo Ads, etc.

### Tracker Blocking
- Blocks analytics scripts (Google Analytics, Facebook Pixel, etc.)
- Prevents tracking cookies
- Blocks heatmap and session recording tools

### Data Compression
- Monitors web requests and responses
- Estimates data savings from blocked content
- Tracks compression ratios
- Reduces bandwidth usage by 50-90%

## Privacy

- **No data collection**: All processing happens locally
- **No external servers**: Extension doesn't send data anywhere
- **Open source**: Code is transparent and auditable
- **No tracking**: We don't track your browsing

## Statistics

The extension tracks:
- Number of ads blocked
- Number of trackers blocked
- Total requests blocked
- Data saved (estimated)
- Compression ratio

## Permissions

The extension requires these permissions:

- `declarativeNetRequest`: To block ads and trackers
- `storage`: To save statistics and settings
- `webRequest`: To monitor and compress traffic
- `tabs`: To apply blocking rules to all tabs
- `<all_urls>`: To work on all websites

## Blocked Domains

### Ad Networks
- doubleclick.net
- googlesyndication.com
- googleadservices.com
- facebook.com/tr
- ads.yahoo.com
- advertising.com
- adnxs.com
- taboola.com

### Trackers
- google-analytics.com
- googletagmanager.com
- facebook.com/plugins
- hotjar.com
- mixpanel.com
- segment.com
- amplitude.com
- mouseflow.com
- crazyegg.com

## Performance

- **Memory usage**: ~20-30 MB
- **CPU impact**: Minimal (<1%)
- **Page load speed**: Faster (due to blocked content)
- **Battery impact**: Reduced (less data transfer)

## Compatibility

- Chrome 88+
- Edge 88+
- Brave (Chromium-based)
- Opera (Chromium-based)

## Troubleshooting

### Extension not working
1. Make sure it's enabled in `chrome://extensions/`
2. Try disabling and re-enabling
3. Reload the page you're testing on

### Some ads still showing
- Some websites use anti-adblock techniques
- Try refreshing the page
- Report the website for us to add to blocklist

### Statistics not updating
- Click the extension icon to refresh
- Statistics update every 2 seconds

## Contributing

Contributions are welcome! To add more ad/tracker domains:

1. Edit `rules/ads.json` or `rules/trackers.json`
2. Add new blocking rules
3. Test the changes
4. Submit a pull request

## Roadmap

- [ ] Firefox support
- [ ] Custom blocklist editor
- [ ] Whitelist functionality
- [ ] Export/import settings
- [ ] Advanced compression options
- [ ] Detailed analytics dashboard
- [ ] Sync settings across devices

## License

Apache License 2.0

## Author

Beauttah Kipruto

## Contact

Email: kiprutobeauttah@gmail.com

## Version

1.0.0

## Changelog

### v1.0.0 (2026-03-08)
- Initial release
- Ad blocking functionality
- Tracker blocking functionality
- Data compression
- Real-time statistics
- Toggle controls
- Beautiful UI

## Support

For issues, questions, or feature requests:
- Email: kiprutobeauttah@gmail.com
- GitHub Issues: [Create an issue]

## Disclaimer

This extension is for educational and personal use. Always respect website terms of service and content creator rights.
